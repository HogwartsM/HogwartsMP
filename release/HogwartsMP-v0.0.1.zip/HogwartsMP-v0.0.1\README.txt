HogwartsMP vv0.0.1 
 
Installation: 
1. Extract this archive 
2. Run server/HogwartsMPServer.exe to start the server 
3. Run launcher/HogwartsMPLauncher.exe to play 
 
The launcher will ask for your Hogwarts Legacy installation path. 
